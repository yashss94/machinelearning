import numpy as np
from scipy.spatial import distance

B1 = np.array([[-1],
      [2],
      [1],
      [2],
      [-1],
      [0]])


B2 = np.array([[-2],
      [1],
      [2],
      [3],
      [2],
      [1]])


B3 = np.array([[-1],
      [3],
      [0],
      [1],
      [3],
      [-1]])


B4 = np.array([[0],
      [2],
      [3],
      [1],
      [1],
      [-2]])

B = np.column_stack((B1, B2, B3, B4))

A = np.array([[0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0]])

sum_rows = [0.0] * 6
mew = [0.0] * 6

for i in range(0, 6):
    for j in range(0, 4):
        sum_rows[i] += B[i][j]

for i in range(0, 6):
    mew[i] = sum_rows[i] / 4.0

for i in range(0, 6):
    for j in range(0, 4):
        A[i][j] = B[i][j] - mew[i]


A_transpose = np.transpose(A)

C = (1.0 / 4) * (np.dot(A, A_transpose))
print ("Covariance Matrix is:")
print C
# U, s, Vh = np.linalg.svd(A, full_matrices=True)

s, U = np.linalg.eig(C)
np.set_printoptions(formatter={'float_kind': '{:f}'.format})
np.set_printoptions(suppress=True)
print("Eigen Vector Matrix is:")
print U
print("Eigen Values are:")
print s
U_transpose = np.transpose(U)

scoringMatrix = U_transpose.dot(A)
InverseDelta = np.delete(scoringMatrix, [3, 4, 5], 0)
print ("The Inverse Delta scoring Matrix is:")
print InverseDelta
